// This libcanard config header is included from canard.c via CANARD_CONFIG_HEADER

// Expose the internal definitions for testing.
#define CANARD_PRIVATE
