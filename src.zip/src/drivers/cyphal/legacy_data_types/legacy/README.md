UAVCAN Legacy 
================

Port of legacy UAVCAN v0 messages from
https://github.com/UAVCAN/public_regulated_data_types/tree/legacy-v0

Disclaimer

DO NOT USE IN PRODUCTION, this is for testing only and is unmaintained 
