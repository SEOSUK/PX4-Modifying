# Septentrio GNSS Driver

## SBF Library

The `sbf/` directory contains all the logic required to work with SBF, including message
definitions, block IDs and a simple parser for the messages used by PX4.